/**
 * NexChat Landing - Pure JS
 * nexchat.site
 */

(function () {
  'use strict';
  // لا يوجد سكربت مطلوب حالياً
})();
